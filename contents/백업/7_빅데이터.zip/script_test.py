def f(x, y, z):
    return (x+y)/z
    
a=5
b=6
c=7.5

result = f(a, b, c)

