import sqlite3
con = sqlite3.connect("./test.db")
cur = con.cursor()
cur.execute("select * from PhoneBook;")
print(cur.fetchall())
